export default function Browse() {
  return <h1>تصفح القصص</h1>;
}