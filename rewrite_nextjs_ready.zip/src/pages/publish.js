export default function Publish() {
  return <h1>صفحة نشر قصة جديدة</h1>;
}