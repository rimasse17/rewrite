export default function Dashboard() {
  return <h1>لوحة التحكم</h1>;
}