export default function Story() {
  return <h1>صفحة عرض القصة</h1>;
}