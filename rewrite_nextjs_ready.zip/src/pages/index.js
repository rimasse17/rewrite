export default function Home() {
  return <h1>مرحبًا بك في منصة Rewrite</h1>;
}