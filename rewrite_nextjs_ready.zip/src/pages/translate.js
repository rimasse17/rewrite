export default function Translate() {
  return <h1>دعم الترجمة</h1>;
}